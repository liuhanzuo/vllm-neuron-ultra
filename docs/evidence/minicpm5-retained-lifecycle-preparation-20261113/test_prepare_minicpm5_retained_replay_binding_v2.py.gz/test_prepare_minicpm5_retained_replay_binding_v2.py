"""Injected synthetic JSON only; no actual plan/History/lock/native payload IO."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

Q=Path(__file__).resolve().parent;sys.path[:0]=[str(Q),str(Q.parent)]
import prepare_minicpm5_retained_replay_binding_v2 as p


def digest(data):return hashlib.sha256(data).hexdigest()


class Fixture:
    def __init__(self):
        self.saved={};self.calls=[];self.guards=0;self.next_inode=1;self.fresh=[]
        self.caller={path:self.source(path,Path(path).read_bytes())['sha256']for path in p.c.FILES}
        self.v2=self.source(p.finalizer.SELF,Path(p.finalizer.SELF).read_bytes())
        for path,sha in p.c.FROZEN.items():assert self.source(path,Path(path).read_bytes())['sha256']==sha
        self.helper={path:self.source(path,Path(path).read_bytes())['sha256']for path in p.REQUIRED_SOURCES}
        original_pins={str(Q/('synthetic-original-%04d.py'%i)):'a'*64 for i in range(1869)}
        self.original=self.metadata('synthetic-original-replay-plan',dict(source_sha256=original_pins,
            analysis_payloads={('/tmp/synthetic-never-open-%05d.raw'%i):dict(identity={},sha256='b'*64)for i in range(11859)}))
        self.plan=self.metadata('synthetic-pair-plan',dict(entries=[dict(index=i)for i in range(2352)]))
        self.old_accept=self.metadata('synthetic-raw-acceptance',dict(passed=True,source_ready_for_caller_integration=True,
            launch_authorized=False,production_deletion_admitted=False))
        caller_delivery=self.metadata('synthetic-caller-delivery',dict(schema='minicpm5_retained_replay_caller_source_delivery_v1',
            mandatory_new_source_sha256=self.caller,launch_authorized=False))
        finalizer_delivery=self.metadata('synthetic-finalizer-delivery',dict(schema='minicpm5_retained_replay_finalizer_v2_source_delivery_v1',
            mandatory_new_source_pin=self.v2,launch_authorized=False))
        self.mini_review=self.metadata('synthetic-mini-source-review',dict(schema='minicpm5_retained_caller_finalizer_v2_root_source_review_v1',
            reviewer='/root',passed=True,source_accepted=True,blockers=[],launch_authorized=False,runtime_admitted=False,
            production_deletion_admitted=False,required_finalization_entry='minicpm5_retained_replay_finalizer_v2.py',
            original_finalizer_v1_admitted=False,caller_delivery=caller_delivery,finalizer_delivery=finalizer_delivery))
        prep_delivery=self.metadata('synthetic-preparer-delivery',dict(schema='minicpm5_retained_replay_preparer_source_delivery_v2',
            source_only=True,launch_authorized=False,source_sha256=self.helper))
        prep_review=self.metadata('synthetic-preparer-source-review',dict(schema='minicpm5_retained_replay_preparer_root_source_review_v2',
            reviewer='/root',source_accepted=True,passed=True,blockers=[],runtime_admitted=False,source_delivery=prep_delivery))
        self.scope=self.metadata('synthetic-lfm-scope',dict(schema='lfm3_full_cpu_successor_scope_v1',
            children=[dict(pid=i+100,start_ticks=str(i+1),retained_extra='all child fields')for i in range(874)]))
        inherited=self.metadata('synthetic-inherited-input',dict(retained='exact-original'))
        self.inherited_row=dict(sha256=inherited['sha256'],identity=self.saved[inherited['path']]['identity'])
        self.base=self.metadata('synthetic-base-plan',dict(source_sha256=original_pins,
            inputs={'/tmp/synthetic-base-never-open.raw':dict(sha256='f'*64,identity=self.ident('/tmp/synthetic-base-never-open.raw',1))}))
        self.old_row=dict(terminal=self.metadata('synthetic-old-terminal',dict(original_failure=True)),
            tool=dict(kind='tool_session',session_id=1,terminal_chunk='old-failed',exit_code=1),
            owners=[dict(pid=11,start_ticks='111')],units=['synthetic-old-service'],source_sha256={str(Q/'synthetic-old.py'):'c'*64})
        idle=self.metadata('synthetic-idle',dict(serial_execution=True,running=False,active_serial=None,
            live_tool_sessions=[],active_heavy_units=[],original_failure=True))
        self.old_catalog=self.metadata('synthetic-old-catalog',self.catalog([self.old_row],idle))
        overlay=self.metadata('synthetic-seed-overlay',dict(schema='minicpm5_layer1_operator_native_small_overlay_v2',
            base_plan=self.base,sdk_operator_recovery=self.metadata('synthetic-recovered',{}),current_serial_catalog=self.old_catalog,
            native_manifest=self.metadata('synthetic-native-metadata',{}),source_extension={str(Q/'synthetic-old.py'):'c'*64},
            input_extension={inherited['path']:self.inherited_row},output_root='/mnt/nvme/minicpm5-layer1-operator-native-synthetic-seed'))
        seed_sources=dict(original_pins,**self.old_row['source_sha256'])
        seed=self.metadata('synthetic-seed-spec',dict(run_name='synthetic-seed',output_root='/tmp/synthetic-old-output',
            lock_identity=p.c.LOCK,automatic_successor=False,source_sha256=seed_sources,history_overlay=overlay,
            current_serial_catalog=self.old_catalog,lfm_r2_scope=self.scope,input_extension={inherited['path']:self.inherited_row}))
        review=self.metadata('synthetic-seed-review',dict(reviewer='/root',passed=True,launch_authorized=True,blockers=[],
            spec=seed,source_sha256=seed_sources))
        binding=self.metadata('synthetic-seed-binding',dict(reviewer='/root',passed=True,full_source_history_resolution_passed=True,
            original_failed_statuses_preserved=True,lfm_children=874,spec=seed,review=review,catalog=self.old_catalog,history_overlay=overlay))
        self.tool=dict(kind='tool_session',session_id=2,terminal_chunk='last-failed',exit_code=1)
        self.actual=self.metadata('synthetic-last-actual',dict(reviewer='/root',actual_tool_exit_observed=True,actual_tool=self.tool,
            owners_gone=True,physically_drained=True,owners=[dict(pid=22,start_ticks='222')],units=['synthetic-last-service'],lock_identity=p.c.LOCK))
        self.new_row=dict(terminal=self.actual,tool=self.tool,owners=[dict(pid=22,start_ticks='222')],units=['synthetic-last-service'],
            source_sha256={str(Q/'synthetic-current.py'):'d'*64})
        current=self.metadata('synthetic-current-catalog',self.catalog([self.old_row,self.new_row],idle))
        self.request=dict(schema='minicpm5_retained_replay_future_binding_v2',seed_spec=seed,seed_review=review,seed_binding=binding,
            catalog=current,idle_handoff=idle,prerequisite_exit=self.actual,prerequisite_tool=self.tool,mini_source_review=self.mini_review,
            preparer_source_review=prep_review,preparer_delivery=prep_delivery,
            future=dict(run_name='synthetic-mini',overlay_path=str(Q/'synthetic-mini-overlay.json'),
                overlay_output_root='/mnt/nvme/minicpm5-layer1-operator-native-synthetic-mini',spec_path=str(Q/'synthetic-mini-spec.json'),
                review_draft_path=str(Q/'synthetic-mini-review-draft.json'),review_path=str(Q/'synthetic-mini-review.json'),candidate_path=str(Q/'synthetic-mini-candidate.json')))
        successor_delivery=self.metadata('synthetic-lifecycle-delivery',dict(
            schema='minicpm5_retained_replay_lifecycle_source_delivery_v1',source_only=True,launch_authorized=False,
            mandatory_new_source_sha256={path:self.helper[path]for path in p.successor.SUCCESSOR_FILES}))
        successor_review=self.metadata('synthetic-lifecycle-review',dict(
            schema='minicpm5_retained_replay_lifecycle_root_source_review_v1',reviewer='/root',passed=True,
            source_accepted=True,blockers=[],runtime_admitted=False,launch_authorized=False,
            production_deletion_admitted=False,source_delivery=successor_delivery))
        self.request.update(successor_delivery=successor_delivery,successor_source_review=successor_review)
    def ident(self,path,size):
        self.next_inode+=1;return dict(realpath=path,device=1,inode=self.next_inode,size=size,mtime_ns=123,ctime_ns=456)
    def source(self,path,data):
        ref=dict(path=str(path),sha256=digest(data));self.saved[str(path)]=dict(payload=data,identity=self.ident(str(path),len(data)));return ref
    def metadata(self,name,value):return self.source(str(Q/(name+'.json')),p.encode(value))
    def catalog(self,rows,idle):
        return dict(schema='minicpm5_operator_later_serial_metadata_catalog_v1',reviewer='/root',passed=True,blockers=[],
            completed_sdk=dict(path=str(Q/'synthetic-completed-sdk.json'),sha256='e'*64),current_handoff=idle,all_later_serial_runs_included=True,runs=rows)
    def read(self,ref,cap):
        assert Path(ref['path']).suffix in ('.py','.json');self.calls.append((ref['path'],cap));return copy.deepcopy(self.saved[ref['path']])
    def identity(self,path):
        assert Path(path).suffix in ('.py','.json');return copy.deepcopy(self.saved[path]['identity'])
    def guard(self):self.guards+=1
    def fresh_path(self,path):self.fresh.append(path);return True
    def mutate(self,ref,fn):
        value=json.loads(self.saved[ref['path']]['payload']);fn(value)
        updated=self.source(ref['path'],p.encode(value));ref['sha256']=updated['sha256']
        return value
    def run(self):
        with patch.object(p.c,'ORIGINAL_PLAN',self.original),patch.object(p.c,'PLAN',self.plan),patch.object(p.c,'ACCEPTED',self.old_accept),patch.object(p,'MINI_REVIEW',self.mini_review):
            return p.prepare(self.request,self.read,self.identity,self.fresh_path,self.guard)


class Preparation(unittest.TestCase):
    def test_complete_candidate_no_binary_or_plan_disk_io(self):
        f=Fixture()
        with patch('builtins.open',side_effect=AssertionError('No filesystem IO')),patch.object(Path,'open',side_effect=AssertionError('No filesystem IO')):
            out=f.run()
        spec=out['values']['spec'];candidate=out['values']['candidate'];draft=out['values']['review_draft']
        self.assertEqual(candidate['preservation']['original_sources'],1869);self.assertEqual(candidate['preservation']['original_logical_inputs'],11859)
        self.assertEqual(candidate['preservation']['original_pairs'],2352);self.assertEqual(candidate['preservation']['lfm_children'],874)
        self.assertFalse(draft['passed']);self.assertFalse(draft['launch_authorized']);self.assertFalse(draft['deletion_authorized'])
        self.assertEqual(spec['source_sha256'][p.finalizer.SELF],f.v2['sha256']);self.assertEqual(spec['lock_identity'],p.c.LOCK)
        self.assertEqual(spec['limits'],p.c.LIMITS);self.assertEqual(candidate['actual_prerequisite_tool']['exit_code'],1)
        self.assertEqual(len(out['files']),4);self.assertEqual(spec['input_extension'][f.inherited_row['identity']['realpath']],f.inherited_row)
        self.assertNotIn(f.original['path'],spec['input_extension']);self.assertIn(f.original['path'],candidate['preparation_only_references'])
        self.assertFalse(any(Path(path).suffix in ('.raw','.pt','.bin')for path,_ in f.calls));self.assertGreater(f.guards,0)
    def test_every_old_and_current_source_retained(self):
        f=Fixture();out=f.run();spec=out['values']['spec'];seed=json.loads(f.saved[f.request['seed_spec']['path']]['payload'])
        for path,sha in seed['source_sha256'].items():self.assertEqual(spec['source_sha256'][path],sha)
        for row in (f.old_row,f.new_row):
            for path,sha in row['source_sha256'].items():self.assertEqual(spec['source_sha256'][path],sha)
        for path,sha in p.c.FROZEN.items():self.assertEqual(spec['source_sha256'][path],sha)
    def test_seed_review_source_map_change_rejected(self):
        f=Fixture();f.mutate(f.request['seed_review'],lambda v:v['source_sha256'].update({'/tmp/unknown.py':'a'*64}))
        f.mutate(f.request['seed_binding'],lambda v:v.update(review=f.request['seed_review']))
        with self.assertRaisesRegex(ValueError,'seed source map'):f.run()
    def test_missing_original_child_rejected(self):
        f=Fixture();f.mutate(f.scope,lambda v:v['children'].pop())
        # Retain reference lineage and digest update inside seed itself.
        f.mutate(f.request['seed_spec'],lambda v:v.update(lfm_r2_scope=f.scope))
        seed=f.request['seed_spec'];f.mutate(f.request['seed_review'],lambda v:v.update(spec=seed))
        f.mutate(f.request['seed_binding'],lambda v:v.update(spec=seed,review=f.request['seed_review']))
        with self.assertRaisesRegex(ValueError,'original874'):f.run()
    def test_catalog_prefix_cannot_drop_original_failed_row(self):
        f=Fixture();f.mutate(f.request['catalog'],lambda v:v['runs'].pop(0))
        with self.assertRaisesRegex(ValueError,'ordered catalog'):f.run()
    def test_saved_live_handoff_rejected(self):
        f=Fixture();f.mutate(f.request['idle_handoff'],lambda v:v.update(running=True,live_tool_sessions=[10]))
        f.mutate(f.request['catalog'],lambda v:v.update(current_handoff=f.request['idle_handoff']))
        with self.assertRaisesRegex(ValueError,'idle evidence'):f.run()
    def test_wrong_actual_prerequisite_tool_rejected(self):
        f=Fixture();f.request['prerequisite_tool']=dict(f.tool,session_id=999)
        with self.assertRaisesRegex(ValueError,'last predecessor'):f.run()
    def test_source_conflict_rejected(self):
        f=Fixture();p0=next(iter(f.old_row['source_sha256']))
        f.mutate(f.request['catalog'],lambda v:v['runs'][-1]['source_sha256'].update({p0:'f'*64}))
        with self.assertRaisesRegex(ValueError,'source pin conflict'):f.run()
    def test_helper_self_source_must_be_enrolled(self):
        f=Fixture();f.mutate(f.request['preparer_delivery'],lambda v:v['source_sha256'].pop(p.SELF))
        f.mutate(f.request['preparer_source_review'],lambda v:v.update(source_delivery=f.request['preparer_delivery']))
        with self.assertRaisesRegex(ValueError,'import closure'):f.run()
    def test_corrupt_source_bytes_rejected(self):
        f=Fixture();f.saved[p.c.FILES[2]]['payload']+=b'\n'
        with self.assertRaisesRegex(ValueError,'authenticated bytes'):f.run()
    def test_late_input_identity_change_rejected(self):
        f=Fixture();original=f.identity;target=f.request['seed_binding']['path']
        def changed(path):
            value=original(path)
            if path==target:value['inode']+=1
            return value
        f.identity=changed
        with self.assertRaisesRegex(ValueError,'changed before candidate return'):f.run()
    def test_inherited_identity_not_refreshed(self):
        f=Fixture();path=f.inherited_row['identity']['realpath'];f.saved[path]['identity']['inode']+=1
        with self.assertRaisesRegex(ValueError,'inherited metadata identity'):f.run()
    def test_historical_output_collision_rejected(self):
        f=Fixture();f.request['future']['spec_path']=f.request['seed_spec']['path']
        with self.assertRaisesRegex(ValueError,'disjoint'):f.run()
    def test_occupied_output_rejected(self):
        f=Fixture();f.fresh_path=lambda path:False
        with self.assertRaisesRegex(ValueError,'prospective path absent'):f.run()
    def test_wrong_original_plan_cardinality_rejected(self):
        f=Fixture();f.mutate(f.original,lambda v:v['analysis_payloads'].pop(next(iter(v['analysis_payloads']))))
        with self.assertRaisesRegex(ValueError,'11859'):f.run()
    def test_wrong_pair_count_rejected(self):
        f=Fixture();f.mutate(f.plan,lambda v:v['entries'].pop())
        with self.assertRaisesRegex(ValueError,'2352'):f.run()
    def test_inherited_large_source_metadata_gets_exact_hash_size_envelope(self):
        f=Fixture();ref=f.metadata('synthetic-inherited-large',dict(value='x'*(p.ORDINARY+3)))
        f.mutate(f.request['catalog'],lambda v:v['runs'][-1]['source_sha256'].update({ref['path']:ref['sha256']}))
        out=f.run();row=out['values']['spec']['exact_envelopes'][ref['path']]
        self.assertEqual(row,dict(sha256=ref['sha256'],bytes=f.saved[ref['path']]['identity']['size'],role='complete_json_metadata_envelope'))
        self.assertEqual(out['values']['spec']['source_sha256'][ref['path']],ref['sha256'])
        self.assertEqual(out['values']['spec']['input_extension'][ref['path']]['identity'],f.saved[ref['path']]['identity'])
    def test_finalizer_source_pin_conflict_is_not_replaced(self):
        f=Fixture();f.mutate(f.request['catalog'],lambda v:v['runs'][-1]['source_sha256'].update({p.finalizer.SELF:'0'*64}))
        with self.assertRaisesRegex(ValueError,'source pin conflict'):f.run()
    def test_only_failed_review_draft_is_returned(self):
        f=Fixture();out=f.run()
        for name in ('review_draft','candidate'):
            self.assertFalse(out['values'][name]['passed']);self.assertFalse(out['values'][name]['launch_authorized'])
        self.assertNotIn(f.request['future']['review_path'],out['files'])
    def test_future_run_cannot_reuse_seed_run(self):
        f=Fixture();f.request['future']['run_name']='synthetic-seed'
        with self.assertRaisesRegex(ValueError,'disjoint'):f.run()
    def test_guard_failure_prevents_any_metadata_read(self):
        f=Fixture()
        def fail():raise ValueError('External preparation window changed')
        f.guard=fail
        with self.assertRaisesRegex(ValueError,'preparation window'):f.run()
        self.assertEqual(f.calls,[])
    def test_no_binary_source_can_be_added_by_preparer_manifest(self):
        f=Fixture();f.mutate(f.request['preparer_delivery'],lambda v:v['source_sha256'].update({'/tmp/synthetic-forbidden.bin':'c'*64}))
        f.mutate(f.request['preparer_source_review'],lambda v:v.update(source_delivery=f.request['preparer_delivery']))
        with self.assertRaisesRegex(ValueError,'no binary payload'):f.run()
        self.assertFalse(any(path.endswith('.bin')for path,_ in f.calls))
    def test_saved_predecessor_owners_cannot_be_dropped(self):
        f=Fixture();f.mutate(f.request['catalog'],lambda v:v['runs'][-1].update(owners=[]))
        with self.assertRaisesRegex(ValueError,'last predecessor'):f.run()
    def test_seed_binding_must_preserve_original_failed_statuses(self):
        f=Fixture();f.mutate(f.request['seed_binding'],lambda v:v.update(original_failed_statuses_preserved=False))
        with self.assertRaisesRegex(ValueError,'complete seed History'):f.run()
    def test_cannot_select_old_v1_finalization(self):
        f=Fixture();f.mutate(f.mini_review,lambda v:v.update(original_finalizer_v1_admitted=True))
        f.request['mini_source_review']=f.mini_review
        with self.assertRaisesRegex(ValueError,'corrected Mini source'):f.run()


class SuccessorPreparation(unittest.TestCase):
    def test_all_successor_paths_and_sources_bound_before_runtime(self):
        f=Fixture();out=f.run();spec=out['values']['spec']
        self.assertEqual(spec['schema'],'minicpm5_retained_replay_caller_spec_v2')
        self.assertEqual(out['values']['review_draft']['schema'],'minicpm5_retained_replay_caller_source_review_v2')
        for path in p.successor.SUCCESSOR_FILES:self.assertEqual(spec['source_sha256'][path],f.helper[path])
        for path in spec['publication_paths'].values():self.assertIn(path,out['future_paths'])
        self.assertEqual(out['values']['candidate']['final_publisher']['path'],p.successor.SUCCESSOR_FILES[4])
        self.assertFalse(out['values']['candidate']['launch_authorized'])
    def test_unaccepted_successor_cannot_prepare(self):
        f=Fixture();f.mutate(f.request['successor_source_review'],lambda v:v.update(passed=False))
        with self.assertRaisesRegex(ValueError,'Separate root source acceptance'):f.run()
    def test_omitted_successor_module_rejected(self):
        f=Fixture();f.mutate(f.request['successor_delivery'],lambda v:v['mandatory_new_source_sha256'].pop(p.successor.SUCCESSOR_FILES[2]))
        f.mutate(f.request['successor_source_review'],lambda v:v.update(source_delivery=f.request['successor_delivery']))
        with self.assertRaisesRegex(ValueError,'complete lifecycle successor source delivery'):f.run()
    def test_successor_source_conflict_is_not_replaced(self):
        f=Fixture();f.mutate(f.request['catalog'],lambda v:v['runs'][-1]['source_sha256'].update({p.successor.SUCCESSOR_FILES[1]:'0'*64}))
        with self.assertRaisesRegex(ValueError,'source pin conflict'):f.run()


if __name__=='__main__':unittest.main(verbosity=2)

